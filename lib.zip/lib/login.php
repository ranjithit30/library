<?php
include("log.php");
?>
<!DOCTYPE html>
<html>
<head>
<title>Auth Page</title>
<style>
input{
      width: 100px; /* When specifying this, you can use both px and % */
}
div{
	width: 100px;
	height: 100px;
    position: absolute;
	top:0;
	bottom: 0;
	left: 0;
	right: 0;
  	margin: auto;

}
</style>
</head>
<body>
<div>
<img src="sec.png" alt="sec" height="100" width="100"> 
<br>
<br>
<input type="password" class="pw" required="" style="width: 100px;height: 30px;">
</div>

</body>
</html> 